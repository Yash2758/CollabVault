import 'package:flutter/material.dart';
import 'screens/collab_page.dart';

void main() {
  runApp(const CollabVaultApp());
}

class CollabVaultApp extends StatelessWidget {
  const CollabVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CollabVault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const CollabPage(),
    );
  }
}
